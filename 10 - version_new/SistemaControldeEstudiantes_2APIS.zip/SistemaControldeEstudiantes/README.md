<p align="center"><a href="https://laravel.com" target="_blank"><img src="https://raw.githubusercontent.com/laravel/art/master/logo-lockup/5%20SVG/2%20CMYK/1%20Full%20Color/laravel-logolockup-cmyk-red.svg" width="400"></a></p>


Sistema completo desarrollado con PHP y Laravel para gestionar el control de estudiantes. Un proyecto ideal para aprender conceptos clave del desarrollo web, desde la gestión de datos hasta la implementación de buenas prácticas en Laravel.
