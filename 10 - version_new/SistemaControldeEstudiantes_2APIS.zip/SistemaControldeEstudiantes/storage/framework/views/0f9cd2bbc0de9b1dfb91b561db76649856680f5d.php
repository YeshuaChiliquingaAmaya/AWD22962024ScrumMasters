<?php $__env->startSection('content'); ?>


<div class="row justify-content-center">
<div class="col-md-12 grid-margin stretch-card">
    <div class="card">
        <div class="card-body">
        <h2 class="card-title text-center">ACTUALIZAR DATOS DEL ALUMNO <hr></h2>
        <form class="forms-sample" method="post" action="<?php echo e(route('alumno.update', $alumno->id)); ?>" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          <?php echo method_field('PATCH'); ?>
            <div class="row">
                <div class="col-md-4">
                    <label class="col-sm-6 col-form-label">Nombre y Apellido</label>
                    <div class="col-sm-12">
                      <input type="text" name="nameFullAlumno" class="form-control" value="<?php echo e($alumno->nameFullAlumno); ?>" required/>
                    </div>
                </div>
                <div class="col-md-4">
                    <label class="col-sm-6 col-form-label">Cédula</label>
                    <div class="col-sm-12">
                      <input type="number" name="cedula_alumno" class="form-control" value="<?php echo e($alumno->cedula_alumno); ?>" />
                    </div>
                </div>
                <div class="col-md-4">
                  <label class="col-sm-6 col-form-label">Lugar de expedición de Documento</label>
                  <div class="col-sm-12">
                    <input type="text" name="lugar_exp_document" class="form-control" value="<?php echo e($alumno->lugar_exp_document); ?>"/>
                  </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-4">
                  <label class="col-sm-6 col-form-label">Referencia Familiar</label>
                  <div class="col-sm-12">
                    <input type="text" name="ref_family" class="form-control"  value="<?php echo e($alumno->ref_family); ?>"/>
                  </div>
              </div>
              <div class="col-md-4">
                  <label class="col-sm-6 col-form-label">Celular de la referencia familiar</label>
                  <div class="col-sm-12">
                    <input type="number" name="phone_ref_family" class="form-control" value="<?php echo e($alumno->phone_ref_family); ?>"/>
                  </div>
              </div>
              <div class="col-md-4">
                  <label class="col-sm-6 col-form-label">Talla del Uniforme</label>
                  <div class="col-sm-12">
                    <input type="number" name="talla_uniforme" class="form-control"  value="<?php echo e($alumno->talla_uniforme); ?>"/>
                  </div>
              </div>
          </div>

            <div class="row">
              <div class="col-md-4">
                <label class="col-sm-6 col-form-label">Correo</label>
                <div class="col-sm-12">
                  <input type="email" name="email_alumno" class="form-control" value="<?php echo e($alumno->email_alumno); ?>"/>
                </div>
            </div>
                <div class="col-md-4">
                    <label class="col-sm-6 col-form-label">Ciudad</label>
                    <div class="col-sm-12">
                      <input type="text" name="ciudad" class="form-control" value="<?php echo e($alumno->ciudad); ?>"/>
                    </div>
                </div>
                <div class="col-md-4">
                    <label class="col-sm-6 col-form-label">Teléfono</label>
                    <div class="col-sm-12">
                      <input type="number" name="phone_alumno" class="form-control" value="<?php echo e($alumno->phone_alumno); ?>"/>
                    </div>
                </div>
            </div>

            <div class="row">
              <div class="col-md-4">
                <label class="col-sm-12 col-form-label">Edad del Alumno</label>
                <div class="col-sm-12">
                  <input type="number" name="edad_alumno" class="form-control" value="<?php echo e($alumno->edad_alumno); ?>"/>
                </div>
              </div>
                <div class="col-md-4">
                    <label class="col-sm-12 col-form-label">Dirección</label>
                    <div class="col-sm-12">
                      <input type="text" name="addres" class="form-control" value="<?php echo e($alumno->addres); ?>"/>
                    </div>
                </div>

                <div class="col-md-4">
                    <label class="col-sm-12 col-form-label">Asignar Curso</label>
                    <select name="curso_id" class="form-control form-control-sm">
                        <?php $__currentLoopData = $cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <?php if($curso->id ==$CursoAsignadoBD): ?>
                              <option value="<?php echo e($curso->id); ?>" selected><?php echo e($curso->nombre_curso); ?></option>
                            <?php else: ?>
                              <option value="<?php echo e($curso->id); ?>"><?php echo e($curso->nombre_curso); ?></option>  
                            <?php endif; ?>
                       
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="row  mb-5 mt-3">
              <div class="col-md-4">
                <label class="col-sm-12 col-form-label">Asignar Sede</label>
                <select name="profesor_id" class="form-control form-control-sm">
                    <option value="">Seleccione</option>
                    <?php $__currentLoopData = $profesores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php if($profe->id == $ProfeAsignadoBD): ?>
                          <option value="<?php echo e($profe->id); ?>" selected> <?php echo e($profe->nameFull); ?></option>
                        <?php else: ?>
                          <option value="<?php echo e($profe->id); ?>"> <?php echo e($profe->nameFull); ?></option>
                        <?php endif; ?>
                       
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
              <div class="col-md-2">
                  <label for="exampleInputUsername1" style="text-align: center;">Foto actual</label>
                  <br>
                  <?php if($alumno->foto_estudiante !=NULL): ?>
                      <img src="/fotosAlumnos/<?php echo e($alumno->foto_estudiante); ?>" alt="foto profe" style="max-width: 100px; margin: 0 auto;">
                  <?php else: ?>
                      <img class="card-img-top" src="<?php echo e(asset('images/users.png')); ?>" alt="Foto-Profe" class="imgs" style="width:100px; margin: 0 auto;">
                  <?php endif; ?>
                  
              </div>
              <div class="col-md-2">
                  <label for="exampleInputUsername1">Cambiar Foto</label>
                  <input type="file" name="foto_estudiante" class="form-control">
              </div>
              <div class="col-md-4">
                <label class="col-sm-6 col-form-label">Observación</label>
                <textarea name="observ" class="form-control" rows="4" cols="50"></textarea>
            </div>
          </div>

            <div class="form-group text-center mt-5 mb-3">
                <button type="submit" class="btn btn-primary mr-2 mb-3">Actualizar datos del  Alumno</button>
                <a href="/"  class="btn btn-inverse-dark btn-fw mb-3">Cancelar</a>
            </div>
        </form>
        </div>
    </div>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/yeshua/gitRepos/SistemaControldeEstudiantes/resources/views/alumnos/update.blade.php ENDPATH**/ ?>