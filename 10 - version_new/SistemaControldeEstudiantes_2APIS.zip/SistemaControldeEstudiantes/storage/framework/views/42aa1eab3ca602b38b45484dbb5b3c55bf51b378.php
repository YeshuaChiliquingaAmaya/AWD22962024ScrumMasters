<?php $__env->startSection('content'); ?>


<div class="row justify-content-center">
    <div class="col-md-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
            <h2 class="text-center mb-3">
                <a href="/alumno" class="btn btn-primary">
                    <i class="mdi mdi-undo-variant"></i> Volver
                </a> 
                DETALLES DEL ALUMNO<hr>
            </h2>

        <div class="row">
            <div class="col-md-6">
            <div class="card" style="width: 30rem;">
                <?php if( $alumno->foto_estudiante !=NULL ): ?>
                <img class="card-img-top imgs" src="/fotosAlumnos/<?php echo e($alumno->foto_estudiante); ?>" alt="Foto-Alumno" style="width:200px; margin: 0 auto;">
                <?php else: ?>
                <img class="card-img-top imgs" src="<?php echo e(asset('images/users.png')); ?>" alt="Foto-Alumno" style="width:200px; margin: 0 auto;">   
                <?php endif; ?>
                
                <div class="card-body">
                <h6 class="card-title"><strong>Nombre y Apellido:</strong>
                     <?php echo e($alumno->nameFullAlumno); ?> <hr>
                </h6>
                <h5 class="card-title"><strong>Edad:</strong> 
                    <?php echo e($alumno->edad_alumno); ?> 
                    <hr>
                </h5>
                <h5 class="card-title"><strong>Lugar de expedicion del Documento:</strong> 
                    <?php echo e($alumno->lugar_exp_document); ?> 
                    <hr>
                </h5>
                <h5 class="card-title"><strong>Referencia familiar:</strong> 
                    <?php echo e($alumno->ref_family); ?> 
                    <hr>
                </h5>
                <h5 class="card-title"><strong>Telefomo de la referencia familiar:</strong> 
                    <?php echo e($alumno->phone_ref_family); ?> 
                    <hr>
                </h5>
                <h5 class="card-title"><strong>Talla del uniforme:</strong> 
                    <?php echo e($alumno->talla_uniforme); ?> 
                    <hr>
                </h5>
                <h5 class="card-title"><strong>Correo:</strong> 
                    <?php echo e($alumno->email_alumno); ?> 
                    <hr>
                </h5>
                <h5 class="card-title"><strong>Ciudad:</strong> 
                    <?php echo e($alumno->ciudad); ?> 
                    <hr>
                </h5>
                <h5 class="card-title"><strong>Teléfono:</strong> 
                    <?php echo e($alumno->phone_alumno); ?> 
                    <hr>
                </h5>
                
                <h5 class="card-title"><strong>Dirrección:</strong> 
                    <?php echo e($alumno->addres); ?> 
                    <hr>
                </h5>
                <h5 class="card-title"><strong>Curso:</strong> 
                    <?php echo e($alumno->curso->nombre_curso ?? 'Curso Borrado'); ?> 
                    <hr>
                </h5>
                <h5 class="card-title"><strong>Sede:</strong> 
                    <?php echo e($alumno->profesor->nameFull); ?> 
                    <hr>
                </h5>
                <h5 class="card-title"><strong>Observeción:</strong> 
                    <?php echo e($alumno->profesor->observ); ?> 
                    <hr>
                </h5>
                </div>
            </div>
            </div>

            <div class="col-md-6">
                <?php if(!empty($pagosCursoAlumno)): ?>
                <div class="list-group">
                    <p class="list-group-item list-group-item-action active text-center">
                      RECIBOS DE PAGO DEL ALUMNO
                    </p> 
                    <?php $__currentLoopData = $pagosCursoAlumno; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pago): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p class="list-group-item list-group-item-action" style="display: flex; justify-content: space-between">
                            <span>
                                Aporte: <?php echo e($pago->aporte); ?>  
                            </span>
                            <span class="text-center"> 
                                Fecha: <?php echo e($pago->created_at->format('Y-m-d')); ?> 
                            </span>
                            <span>
                                <a href="/fotosPagos/<?php echo e($pago->photo_pago); ?>" class="btn btn-info" target="_blank">ver recibo</a> 
                            </span>
                        </p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
                <p style="background-color: #f9f9f9; padding:10px 5px; color:#333; font-weight:bold;">
                    TOTAL APORTE: $ <?php echo e($sumaPagoTotal); ?> de <?php echo e($valorCurso); ?>

                </p>
                    <?php if($sumaPagoTotal == $valorCurso): ?>
                        <p style="background-color: #ccc; padding:10px 5px; color:green; font-weight:bold;">
                            El alumno ha cancelado todo el valor del curso.
                        </p>
                    <?php endif; ?>
                <?php else: ?>
                <h3 class="text-center font-weight-bold mt-5" style="color: crimson">
                     No existe ningún pago registrado 
                    </h3>
                <?php endif; ?>
            </div>
        </div>


            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/yeshua/gitRepos/SistemaControldeEstudiantes/resources/views/alumnos/view.blade.php ENDPATH**/ ?>