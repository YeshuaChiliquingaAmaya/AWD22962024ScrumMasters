<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/> <!--Importante--->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Descargar</title>
</head>
<body>
    
<?php
date_default_timezone_set("America/Bogota");
$fecha = date("d/m/Y");

header("Content-Type: text/html;charset=utf-8");
header("Content-Type: application/vnd.ms-excel charset=iso-8859-1");
$filename = "ReportePagos_" .$fecha. ".xls";
header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
header("Content-Disposition: attachment; filename=" . $filename . "");

?>


<table style="text-align: center;" border='1' cellpadding=1 cellspacing=1>
<thead>
    <tr style="background:#cecece;">
        <th>ALUMNO</th>
        <th>CORREO</th>
        <th>CEDULA</th>
        <th>LUGAR. EXP</th>
        <th>TELEFONO</th>
        <th>OBSERVACION</th>
        <th>CURSO</th>
        <th>VALOR DEL CURSO</th>
        <th>APORTE</th>
        <th>FECHA APORTE</th>
    </tr>
</thead>
    <tbody>
        <?php $__currentLoopData = $pagos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pago): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($pago->alumno->nameFullAlumno); ?></td>
            <td><?php echo e($pago->alumno->email_alumno); ?></td>
            <td><?php echo e($pago->alumno->cedula_alumno); ?></td>
            <td><?php echo e($pago->alumno->lugar_exp_document); ?></td>
            <td><?php echo e($pago->alumno->phone_alumno); ?></td>
            <td><?php echo e($pago->alumno->observ); ?></td>
            <td><?php echo e($pago->curso->nombre_curso); ?></td>
            <td><?php echo e($pago->valor_curso); ?></td>
            <td><?php echo e($pago->aporte); ?></td>
            <td><?php echo e($pago->created_at->format('Y-m-d')); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

</body>
</html><?php /**PATH /home/yeshua/gitRepos/SistemaControldeEstudiantes/resources/views/exports/exportPagos.blade.php ENDPATH**/ ?>