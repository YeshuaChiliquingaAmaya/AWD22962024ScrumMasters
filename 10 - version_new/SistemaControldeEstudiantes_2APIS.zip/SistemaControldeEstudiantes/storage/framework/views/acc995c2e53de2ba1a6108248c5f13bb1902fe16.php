<?php $__env->startSection('content'); ?>

<?php echo $__env->make('mensajes', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php if($pagos->count()): ?>
    <div class="col-md-12 grid-margin stretch-card">
    <div class="card">
        <div class="card-body">
        <h4 class="card-title text-center">LISTA DE PAGOS 
            <a class="btn btn-inverse-primary" href="<?php echo e(route('exportPagosAlumnos')); ?>"  style="padding: 8px 15px !important;" title="Ver Detalles"> Descargar</a>
        </h4>
        <div class="table-responsive">
            <table class="table table-hover">
            <thead>
                <tr style="text-align: left;">
                    <th>Nombre del Alumno</th>
                    <th>Curso</th>
                    <th>Valor del Curso</th>
                    <th>Aporte</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $pagos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pago): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($pago->alumno->nameFullAlumno ?? 'Alumno Borrado'); ?></td>
                    <td><?php echo e($pago->curso->nombre_curso ?? 'Curso Borrado'); ?></td>
                    <td><?php echo e($pago->valor_curso); ?></td>
                    <td><?php echo e($pago->aporte); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            </table>

            <br><br>
            <div class="form-group text-center mt5">
                <?php echo $pagos->links(); ?>

            </div>

            </div>
        </div>
    </div>
    </div>
<?php else: ?>
<p> No se han creado Alumnos </p>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/yeshua/gitRepos/SistemaControldeEstudiantes/resources/views/pagos/index.blade.php ENDPATH**/ ?>