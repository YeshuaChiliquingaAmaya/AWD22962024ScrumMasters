<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>"> 
    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <link rel="stylesheet" href="<?php echo e(asset('vendors/mdi/css/materialdesignicons.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendors/base/vendor.bundle.base.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendors/datatables.net-bs4/dataTables.bootstrap4.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/barra/pace2.css')); ?>">

    <link  rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <link  rel="stylesheet" href="<?php echo e(asset('css/bootstrap-select.min.css')); ?>" />

    <link rel="shortcut icon" href="<?php echo e(asset('images/favicon.png')); ?>"/>
    <style>
      select{
        color: #333 !important;
      }
      thead{
        text-align:center;
        background: #cecece;
      }
      .w-5{
        width: 40px !important;
      }

      #sinDeudas h2{
        color: green;
        font-weight: 600;
        background-color: #f9f9f9;
        padding: 15px 5px;
      }
      .sidebar .nav .nav-item.active > .nav-link i, .sidebar .nav .nav-item.active > .nav-link .menu-title, .sidebar .nav .nav-item.active > .nav-link .menu-arrow{
        color: #FF9900 !important;
      }
      .btn-primary {
        color: #fff;
        background-color: #ffb716;
        border-color: #ffb716;
      }
      .btn-primary:hover{
        background-color: #FF9900;
        border-color: #FF9900;
      }
      .nav-link:hover{
        color: #FF9900 !important;
        font-weight: 600;
      }
      .text-primary{
        color: #FF9900 !important;
      }
      .mdi-menu{
        color: #fff !important;
      }
      label{
        max-width: 100% !important;
      }
    </style>
</head>
<body>
    <div id="app">

        <?php echo $__env->make('layouts.menuHorizontal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <?php echo $__env->make('layouts.menuVertical', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <div class="main-panel">
            <div class="content-wrapper">
              
                  <?php echo $__env->yieldContent('content'); ?>

            </div>
          </div>


    </div>


    <?php echo $__env->make('layouts.layoutJS', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <?php echo $__env->yieldContent('script'); ?>
    
</body>
</html>
<?php /**PATH /home/yeshua/gitRepos/SistemaControldeEstudiantes/resources/views/layouts/app.blade.php ENDPATH**/ ?>